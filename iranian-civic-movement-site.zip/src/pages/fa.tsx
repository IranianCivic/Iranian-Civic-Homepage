
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Download, Globe2, Instagram, Twitter, Send } from "lucide-react";

export default function HomePageFa() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '', token: '' });
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = grecaptcha.getResponse();
      if (!token) {
        setError("لطفاً کپچا را تکمیل کنید.");
        return;
      }
      const res = await fetch('https://formspree.io/f/xblgaprq', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          message: formData.message,
          'g-recaptcha-response': token
        }),
      });
      if (res.ok) {
        setSubmitted(true);
        setFormData({ name: '', email: '', message: '', token: '' });
        setError(null);
        grecaptcha.reset();
      } else {
        setError("مشکلی پیش آمد. لطفاً دوباره تلاش کنید.");
      }
    } catch (err) {
      setError("خطای شبکه. لطفاً اتصال خود را بررسی کنید.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 p-6 text-right font-vazir" dir="rtl">
      <script src="https://www.google.com/recaptcha/api.js" async defer></script>
      <div className="max-w-5xl mx-auto">
        <header className="text-center py-10">
          <img src="/logo.png" alt="لوگوی جنبش" className="mx-auto w-40 mb-6" />
          <h1 className="text-4xl font-bold mb-2">جنبش شهروندی ایران</h1>
          <p className="text-xl text-gray-600">آزادی · برابری · عدالت</p>
          <div className="mt-4">
            <a href="/" className="inline-flex items-center text-sm text-blue-600 hover:underline">
              <Globe2 className="ml-2 h-4 w-4" /> English
            </a>
          </div>
        </header>

        <nav className="flex justify-center space-x-6 space-x-reverse mt-6">
          <a href="#home" className="text-gray-700 hover:text-blue-600 font-medium">خانه</a>
          <a href="#about" className="text-gray-700 hover:text-blue-600 font-medium">درباره</a>
          <a href="#program" className="text-gray-700 hover:text-blue-600 font-medium">برنامه</a>
          <a href="#join" className="text-gray-700 hover:text-blue-600 font-medium">همراهی</a>
        </nav>

        <section id="program" className="grid md:grid-cols-2 gap-6 mt-10">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-4">برنامه ما</h2>
              <p className="mb-4">نقشه‌ راه جامع ما را برای آینده‌ای آزاد، سکولار و دموکراتیک در ایران بخوانید.</p>
              <a href="/Iranian_Civic_Movement_Program_Cover.pdf" target="_blank" rel="noopener noreferrer">
                <Button>
                  دانلود فایل PDF <Download className="mr-2 h-4 w-4" />
                </Button>
              </a>
            </CardContent>
          </Card>

          <Card id="join">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-4">همراه شوید</h2>
              <p className="mb-4">به جنبش ما بپیوندید و از طریق کنشگری شهروندی در تغییر مشارکت کنید.</p>
              {submitted ? (
                <p className="text-green-600">از همراهی شما سپاسگزاریم! به‌زودی با شما تماس می‌گیریم.</p>
              ) : (
                <form className="space-y-4" onSubmit={handleSubmit}>
                  <input type="text" name="name" placeholder="نام کامل" className="w-full border p-2 rounded" value={formData.name} onChange={handleChange} required />
                  <input type="email" name="email" placeholder="ایمیل" className="w-full border p-2 rounded" value={formData.email} onChange={handleChange} required />
                  <textarea name="message" placeholder="چرا می‌خواهید بپیوندید؟" className="w-full border p-2 rounded" rows={3} value={formData.message} onChange={handleChange}></textarea>
                  <div className="g-recaptcha" data-sitekey="6LeDbAQrAAAAAIxo10LlzsWIHbqf5fuuJTi32MuS"></div>
                  {error && <p className="text-red-500 text-sm">{error}</p>}
                  <Button type="submit">
                    ارسال <ArrowRight className="mr-2 h-4 w-4" />
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </section>

        <section id="about" className="mt-16">
          <h2 className="text-2xl font-bold mb-4 text-center">درباره جنبش</h2>
          <p className="text-center text-gray-700 max-w-3xl mx-auto">
            جنبش شهروندی ایران یک ابتکار دموکراتیک، غیرحزبی و مستقل است که برای ساختن جامعه‌ای بر پایه آزادی، برابری، عدالت و حکومت سکولار تلاش می‌کند. هدف ما توانمندسازی شهروندان برای شکل‌دادن به آینده‌ای دموکراتیک از طریق شفافیت، مشارکت و کرامت انسانی است.
          </p>
        </section>

        <footer className="text-center mt-16 text-sm text-gray-500">
          <div className="flex justify-center space-x-6 space-x-reverse mb-4">
            <a href="https://instagram.com" target="_blank" className="text-gray-600 hover:text-pink-600">
              <Instagram />
            </a>
            <a href="https://twitter.com" target="_blank" className="text-gray-600 hover:text-blue-500">
              <Twitter />
            </a>
            <a href="https://t.me" target="_blank" className="text-gray-600 hover:text-sky-500">
              <Send />
            </a>
          </div>
          &copy; ۲۰۲۵ جنبش شهروندی ایران. تمامی حقوق محفوظ است.
        </footer>
      </div>
    </div>
  );
}
